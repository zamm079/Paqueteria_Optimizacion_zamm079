# Paqueteria optimizacion

Este paquete contiene funciones de optimizacion